typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef unsigned long size_t;

#define TG_EXPORT __attribute__((visibility("default")))

enum {
    TG_EVENT_SPEED = 1,
    TG_EVENT_HELMET = 2,
    TG_EVENT_DISTRACTION = 3,
    TG_EVENT_RED_LIGHT = 4
};

typedef struct {
    uint32_t version;
    uint32_t event_type;
    double value;
    uint64_t sequence;
    unsigned char simulated;
} TGEvent;

static TGEvent g_last_event = {1, 0, 0.0, 0, 1};
static uint64_t g_sequence = 0;

TG_EXPORT const char *TGSimulatorVersion(void) {
    return "TrafficGuard-Simulation-1.0.0-ios16-arm64";
}

/* Synthetic local test event only. No real enforcement data is accessed. */
TG_EXPORT int TGSimulateEvent(int event_type, double value) {
    if (event_type < TG_EVENT_SPEED || event_type > TG_EVENT_RED_LIGHT) return -1;
    g_last_event.version = 1;
    g_last_event.event_type = (uint32_t)event_type;
    g_last_event.value = value;
    g_last_event.sequence = ++g_sequence;
    g_last_event.simulated = 1;
    return 0;
}

TG_EXPORT int TGGetLastSimulatedEvent(TGEvent *out_event, size_t out_size) {
    if (!out_event || out_size < sizeof(TGEvent)) return -1;
    *out_event = g_last_event;
    return 0;
}

TG_EXPORT uint32_t TGEventStructSize(void) {
    return (uint32_t)sizeof(TGEvent);
}
