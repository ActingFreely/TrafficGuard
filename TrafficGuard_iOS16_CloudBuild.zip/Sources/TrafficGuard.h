#ifndef TRAFFICGUARD_H
#define TRAFFICGUARD_H
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef unsigned long size_t;
enum {
    TG_EVENT_SPEED = 1,
    TG_EVENT_HELMET = 2,
    TG_EVENT_DISTRACTION = 3,
    TG_EVENT_RED_LIGHT = 4
};
typedef struct {
    uint32_t version;
    uint32_t event_type;
    double value;
    uint64_t sequence;
    unsigned char simulated;
} TGEvent;
const char *TGSimulatorVersion(void);
int TGSimulateEvent(int event_type, double value);
int TGGetLastSimulatedEvent(TGEvent *out_event, size_t out_size);
uint32_t TGEventStructSize(void);
#endif
