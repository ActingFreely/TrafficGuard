# TrafficGuard cloud build (iOS 16, arm64)

This project builds a real Mach-O dynamic library using Apple's iOS SDK on a
GitHub-hosted macOS runner. It is a local synthetic-event test library only.
It is not designed to evade real traffic enforcement, suppress camera events,
or alter any platform's violation records.

## Build without owning a Mac

1. On your iPhone, sign in to GitHub and create a new **private** repository.
2. Upload the contents of this ZIP to the repository (keep the `.github`
   folder and its `workflows/build.yml` file).
3. Open the repository's **Actions** tab.
4. Select **Build iOS dylib** and tap **Run workflow**.
5. When the run completes, open it and download the
   `TrafficGuard-iOS16-arm64` artifact.
6. Extract the artifact on the phone. The resulting file is
   `TrafficGuard.dylib`.

The workflow runs on a GitHub macOS machine and uses Apple's iPhoneOS SDK.
No Mac is needed locally. GitHub account and internet access are required.

## Exported API

- `const char *TGSimulatorVersion(void)`
- `int TGSimulateEvent(int event_type, double value)`
- `int TGGetLastSimulatedEvent(TGEvent *out_event, size_t out_size)`
- `uint32_t TGEventStructSize(void)`

Event types: 1 speed simulation, 2 helmet simulation, 3 distraction
simulation, 4 red-light simulation. All generated events are marked simulated.

## Important compatibility note

This is a library for an app you own or a dedicated demo target. A dylib file
does not automatically inject into an App Store app. Loading requires an
authorized compatible loader and an app that permits the integration.
